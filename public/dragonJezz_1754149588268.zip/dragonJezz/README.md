Install

    Install dependencies (preferably in a virtual environment):

pip install pygame numpy

Run the game:

    python dragonballJezz.py

Controls

    Left Click: Fire a vertical beam.

    Right Click: Fire a horizontal beam.

    SPACE: Retry after a failed beam.

    R: Advance after winning a level.

